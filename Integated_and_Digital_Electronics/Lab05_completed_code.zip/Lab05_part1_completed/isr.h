#ifndef ISR_H_
#define ISR_H_
void PDB0_IRQHandler(void);
void FTM0_IRQHandler(void);
void PORTA_IRQHandler(void);
void PORTC_IRQHandler(void);

#endif /* ISR_H_ */
