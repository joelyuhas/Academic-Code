/*
 * isr.c
 */

#include "isr.h"
#include "MK64F12.h"
#include <stdio.h>
#include "uart.h"
#include <stdlib.h>

//variables global to the IRQ handlers which dictates if timer is enabled &  timer counter
int isPress = 0;
int counter = 0;

void PDB0_IRQHandler(void){ //For PDB timer
	// Clear the interrupt
	PDB0_SC &= ~(PDB_SC_PDBIF_MASK); 
	
	// Toggle the output state for RED LED 
	if ((GPIOB_PDOR & (1<<22)) == 0){
    GPIOB_PDOR |= (1<<22);
  }
  else{
    GPIOB_PDOR &= ~(1<<22);
  }

	return;
}
	
void FTM0_IRQHandler(void){ //For FTM timer
	// Clear the interrupt
	FTM0_SC &= ~(FTM_SC_TOF_MASK); 
	
	// Increment timer counter when Switch2 pressed 
  if (isPress == 1){
    counter += 1;
  }
	
	return;
}
	
void PORTA_IRQHandler(void){ //For switch 3
	
	// Clear the interrupt
	PORTA_PCR4 |= (PORT_PCR_ISF_MASK);
  
	// Toggle the timer, Enable/Disable
  PDB0_SC ^= (PDB_SC_PDBEN_MASK);
  
	// Start the trigger with timer[En]
  PDB0_SC |= PDB_SC_SWTRIG_MASK;
    
  PDB0_SC |= PDB_SC_LDOK_MASK;
  
	return;
}
	
void PORTC_IRQHandler(void){ //For switch 2
	// Clear the interrupt
  PORTC_PCR6 |= (PORT_PCR_ISF_MASK);
  char str[256];					// Initialize variable to hold the display message
	
	// Check if Switch2 is pressed
  if ((GPIOC_PDIR & (1 << 6)) == 0){
    isPress = 1;							
    counter = 0;							// Reset timer counter
		FTM0_CNT = 0; 						// Reset FlexTimer
    GPIOB_PDOR &= ~(1 << 21);				// Turn on BLUE LED
  }
  else{
    isPress = 0;
    GPIOB_PDOR |= (1 << 21);				// Turn off BLUE LED

		// Display the amount of time Switch2 is held down in millisecond
    sprintf(str,"\r\n Button held for %d milliseconds!",counter);
    uart_put(str);
  }
	
	return;
}
