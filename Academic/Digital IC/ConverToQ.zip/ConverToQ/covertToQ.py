    

def invertBits(bits):
    reverse = ""
    for i in range(len(bits)):
        if bits[i] == "1":
            reverse += "0"
        else:
            reverse += "1"
    return reverse

def twoComplement(bits):
    bits = invertBits(bits)
    complement = ""
    
    for i in range(len(bits)-1, -1, -1):
        if bits[i] == "1":
            complement = "0" + complement
        else:
            complement = bits[0:i] + "1" + complement
            break
    return complement
    

def extract_m_value(decimalVal, numBit):
    binaryBits = "0"

    if "-" in decimalVal:
        negative = True
        decimalVal = int(decimalVal[1:])
    else:
        negative = False
        decimalVal = int(decimalVal)

    if decimalVal == 10:
        debug = True
        

    for i in range(numBit-1, 0, -1):
        if 2**(i) <= decimalVal:
            decimalVal -= 2**(i)
            binaryBits += "1"
        else:
            binaryBits += "0"

    if 1 < (2*decimalVal):
        binaryBits += "1"
    else:
        binaryBits += "0"

    if negative:
        binaryBits = twoComplement(binaryBits)

    return binaryBits


def extract_n_value(decimalVal, numBit):
    decimalVal = float("0." + decimalVal)
    binaryBit = ""

    for i in range(1, numBit):
        value = 1.0 / 2**(i)
        if value <= decimalVal:
            decimalVal -= value
            binaryBit += "1"
        else:
            binaryBit += "0"

    if (1.0 / 2**(numBit)) < (2*decimalVal):
        binaryBit += "1"
    else:
        binaryBit += "0"
            
    return binaryBit


def convertToQ(m, n):
    fileName = input("Enter file name: ")
    outFilename = input("Enter output file name: ")
    outFile = open(outFilename, "w")
    file = open(fileName, 'r')

    for line in file:
        newLine = ""
        line = line.strip().split("\t")
        isFirst = True
        for item in line:
            if "e" in item:
                m_value = m_value = "0" * (m+1)
                n_value = "0" * n
            else:
                item = item.split(".")
                if len(item) == 2:
                    m_value = extract_m_value(item[0], m)
                    n_value = extract_n_value(item[1], n)
                elif len(item) == 1:
                    m_value = extract_m_value(item[0], m)
                    n_value = "0" * n
                else:
                    print("Error: Not a value number to convert - ", item)

            if isFirst:
                newLine += m_value + "." + n_value
            else:
                newLine += "\t" + m_value + "." + n_value
            isFirst = False
                
        outFile.write(newLine + "\n")
    outFile.close()
    file.close()
            

convertToQ(4, 4)  # m=4, n=4
