

def scale():
    fileName = input("Enter file name: ")
    outFilename = input("Enter output file name: ")
    outFile = open(outFilename, "w")
    file = open(fileName, 'r')

    for line in file:
        newLine = ""
        line = line.strip().split("\t")
        isFirst = True
        for item in line:
            value = (float(2 * int(item)) / float(255)) - 1
            if isFirst:
                newLine += str(value)
            else:
                newLine += "\t" + str(value)
            isFirst = False
        outFile.write(newLine + "\n")
    outFile.close()
    file.close()


scale()




