 function [net,traininfo] = nntrainbp(net,U_train,Y_train,U_test,Y_test,epochs,alpha,lambda,mode,varargin)
%NNTRAINBP Trains the passed network using backpropagation
%   [NET TRAININFO] = NNTRAINBP(NET,U_TRAIN,Y_TRAIN,U_TEST,Y_TEST,EPOCHS,ALPHA,LAMBDA,MODE)
%   trains NET using BP, with training vector U_TRAIN and test vector
%   U_test, and expected outputs Y_train and Y_test.  The network is
%   trained for EPOCHS iterations with learning rate ALPHA and
%   regularization term LAMBDA.
%   MODE is:
%       'batch' for batch training (1 weight update per epoch)
%       'online' for online training (1 weight update per sample per epoch)

%   Author: Cory Merkel
%   Air Force Research Laboratory

% Set defaults and get varargs
verbose = 0;
while ~isempty(varargin)
    switch lower(varargin{1})
          case 'verbose'
              verbose = varargin{2};
          otherwise
              error(['Unexpected option: ' varargin{1}])
    end
    varargin(1:2) = [];
end

m_train = size(U_train,1);
trainmses = zeros(epochs,1);
testmses = zeros(epochs,1);
trainaccuracies = zeros(epochs,1);
testaccuracies = zeros(epochs,1); 

% RPROP parameters
deltW = cell(length(net.layers),1);
dJdWlast = cell(length(net.layers),1);
dW = cell(length(net.layers),1);
deltb = cell(length(net.layers),1);
dJdblast = cell(length(net.layers),1);
db = cell(length(net.layers),1);
for l=2:length(net.layers)
    deltW{l} = 0.01*ones(net.layers{l}.size,net.layers{l-1}.size);
    dJdWlast{l} = zeros(net.layers{l}.size,net.layers{l-1}.size);
    dW{l} = zeros(net.layers{l}.size,net.layers{l-1}.size); 
    deltb{l} = 0.01*ones(1,net.layers{l}.size);
    dJdblast{l} = zeros(1,net.layers{l}.size);
    db{l} = zeros(1,net.layers{l}.size); 
end  
deltmax = 1;
deltmin = 1e-6;
etan    = 0.5;
etap    = 1.2;

for epoch=1:epochs

    dJdW = cell(length(net.layers),1);
    dJdb = cell(1,length(net.layers)); 
    for l=2:length(net.layers)
        dJdW{l} = zeros(net.layers{l}.size,net.layers{l-1}.size);
        dJdb{l} = zeros(1,net.layers{l}.size);
    end

    %% Loop through each training vector
    %  THIS SHOULD BE VECTORIZED FOR PERFORMANCE
    for p=1:m_train

        % Forward propagation
        u = U_train(p,:);
        y = Y_train(p,:);
        net = nnsim(net,u);

        % Create the delta variables
        d = cell(1,length(net.layers));        
        for l=1:length(net.layers)
            d{l} = zeros(1,net.layers{l}.size);
        end

        % Backpropagation to calculate the delta values
        yhat = net.layers{end}.x;
        d{end} = (yhat-y);%.*net.layers{l}.fp(net.layers{end}.s);
        for l=length(net.layers)-1:-1:2
            d{l} = (d{l+1}*net.layers{l+1}.W).*net.layers{l}.fp(net.layers{l}.s+net.layers{l}.b);
        end

        % Loop through to calculate dJdW
        for l=2:length(net.layers)
            switch net.layers{l}.activationtype
                case 'sum'
                    dJdW{l} = dJdW{l} + d{l}'*net.layers{l-1}.x + lambda*net.layers{l}.W;
                    dJdb{l} = dJdb{l} + d{l};
                case 'product'
                    tmp = d{l}.*net.s{l};
                    dJdW{l} = dJdW{l} + tmp(:,ones(1,net.layers{l-1}.size))./net.W{l}+lambda*net.W{l};
                otherwise
                    error(['Invalid Activation Type: ' net.layers{l}.type])
            end
        end

        % Update the weights
        switch mode
            case 'online'                     
                % Calculate the weight updates
                % This just sets dW = -alpha*dJdW
                dW = cellfun(@(x) -alpha*x,dJdW,'UniformOutput',false);
                db = cellfun(@(x) -alpha*x,dJdb,'UniformOutput',false);
                for l=2:length(net.layers)
                    net.layers{l}.W = net.layers{l}.W+dW{l}.*net.layers{l}.Wmask;
                    net.layers{l}.b = net.layers{l}.b+db{l}.*net.layers{l}.bmask;
                    dJdW{l} = zeros(net.layers{l}.size,net.layers{l-1}.size);                   
                    dJdb{l} = zeros(1,net.layers{l}.size);
                end
            case 'batch'
                if p==m_train
                    % Calculate the weight updates
                    % This just sets dW = -alpha*dJdW
%                     dW = cellfun(@(x) -alpha*x,dJdW,'UniformOutput',false);
%                     db = cellfun(@(x) -alpha*x,dJdb,'UniformOutput',false);

                    % RPROP
                    for l=2:length(net.layers)
                        deltW{l} = ((dJdWlast{l}.*dJdW{l})>0).*min(deltW{l}*etap,deltmax)+...
                                 ((dJdWlast{l}.*dJdW{l})<0).*max(deltW{l}*etan,deltmin)+...
                                 ((dJdWlast{l}.*dJdW{l})==0).*deltW{l};
                        dW{l}   = ((dJdWlast{l}.*dJdW{l})>0).*(-sign(dJdW{l}).*deltW{l})+...
                                 ((dJdWlast{l}.*dJdW{l})<0).*(-dW{l})+...
                                 ((dJdWlast{l}.*dJdW{l})==0).*(-sign(dJdW{l}).*deltW{l});
                        dJdW{l} = ((dJdWlast{l}.*dJdW{l})>=0).*dJdW{l};          
                        deltb{l} = ((dJdblast{l}.*dJdb{l})>0).*min(deltb{l}*etap,deltmax)+...
                                 ((dJdblast{l}.*dJdb{l})<0).*max(deltb{l}*etan,deltmin)+...
                                 ((dJdblast{l}.*dJdb{l})==0).*deltb{l};
                        db{l}   = ((dJdblast{l}.*dJdb{l})>0).*(-sign(dJdb{l}).*deltb{l})+...
                                 ((dJdblast{l}.*dJdb{l})<0).*(-db{l})+...
                                 ((dJdblast{l}.*dJdb{l})==0).*(-sign(dJdb{l}).*deltb{l});
                        dJdb{l} = ((dJdblast{l}.*dJdb{l})>=0).*dJdb{l};
                    end
                    dJdWlast = dJdW;
                    dJdblast = dJdb;

                    for l=2:length(net.layers)
                        net.layers{l}.W = net.layers{l}.W+dW{l}.*net.layers{l}.Wmask;
                        net.layers{l}.b = net.layers{l}.b+db{l}.*net.layers{l}.bmask;
                    end

                end
            otherwise
                error(['Invalid Training Mode: ' mode])
        end
    end


%         % Constrain shared weights
%         for l=2:length(net.layers)
%             if isfield(net.layers{l},'Wshare')
%                 for i=1:length(net.layers{l}.Wshare)
%                     shared = net.layers{l}.Wshare{i};
%                     %net.layers{l}.W(shared,:) = repmat(mean(net.layers{l}.W(shared,:)),length(shared),1);
%                     meanweights = mean(net.layers{l}.W(shared,:),1);
%                     net.layers{l}.W(shared,:) = meanweights(ones(length(shared),1),:);
%                 end
%             end
%         end

    % Constrain weights between wmin and wmax
    for l=2:length(net.layers)
        net.layers{l}.W(net.layers{l}.W<net.layers{l}.Wmin) = net.layers{l}.Wmin(net.layers{l}.W<net.layers{l}.Wmin);
        net.layers{l}.b(net.layers{l}.b<net.layers{l}.bmin) = net.layers{l}.bmin(net.layers{l}.b<net.layers{l}.bmin);
        net.layers{l}.W(net.layers{l}.W>net.layers{l}.Wmax) = net.layers{l}.Wmax(net.layers{l}.W>net.layers{l}.Wmax);
        net.layers{l}.b(net.layers{l}.b>net.layers{l}.bmax) = net.layers{l}.bmax(net.layers{l}.b>net.layers{l}.bmax);
    end 


    % Display epoch results
    [net,J_train] = nngetcost(net,U_train,Y_train);
    trainmses(epoch) = J_train.mse;
    trainaccuracies(epoch) = J_train.accuracy;
    [net,J_test] = nngetcost(net,U_test,Y_test);
    testmses(epoch) = J_test.mse;
    testaccuracies(epoch) = J_test.accuracy;
    if(verbose)
        fprintf('Epoch: %d\n',epoch);
        fprintf('Train MSE: %f\n',trainmses(epoch));
        fprintf('Train Accuracy: %f\n',trainaccuracies(epoch));
        fprintf('Test MSE: %f\n',testmses(epoch));
        fprintf('Test Accuracy: %f\n',testaccuracies(epoch));
        drawnow();
    end
end

% Get the final outputs
yhat_train = zeros(size(Y_train));
for p=1:size(U_train,1)
    net = nnsim(net,U_train(p,:));
    yhat_train(p,:) = net.layers{end}.x;
end
yhat_test = zeros(size(Y_test));
for p=1:size(U_test,1)
    net = nnsim(net,U_test(p,:));
    yhat_test(p,:) = net.layers{end}.x;
end

traininfo = struct('trainmses','trainaccuracies','testmses','testaccuracies','yhat_train','yhat_test');
traininfo.trainmses = trainmses;
traininfo.trainaccuracies = trainaccuracies;
traininfo.testmses = testmses;
traininfo.testaccuracies = testaccuracies;
traininfo.yhat_train = yhat_train;
traininfo.yhat_test = yhat_test;
