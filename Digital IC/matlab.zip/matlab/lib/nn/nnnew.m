function net = nnnew(layers,varargin) 
%NNNEW creates a new neural network structure
%   NET = NNNEW(LAYERS) 
%   creates a new neural network structure specified by LAYERS.
%   
%   OPTIONS:
%       'Wmin' and 'Wmax' specify the minimum and maximum weight values
%       Weights will be clipped to fall within this range during training

%   Author: Cory Merkel
%   Air Force Research Laboratory

net.layers = layers;

% Create layers
for l=1:length(layers)
    if ~isfield(net.layers{l},'type')
        net.layers{l}.type = 'fc';
    end
    if ~isfield(net.layers{l},'activationtype')
        net.layers{l}.activationtype = 'sum';
    end
    if l>1
        if ~isfield(net.layers{l},'wmin')
            net.layers{l}.wmin = -1000;
        end
        if ~isfield(net.layers{l},'wmax')
            net.layers{l}.wmax = 1000;
        end
        if ~isfield(net.layers{l},'bmin')
            net.layers{l}.bmin = -1000;
        end
        if ~isfield(net.layers{l},'bmax')
            net.layers{l}.bmax = 1000;
        end
    end
    switch net.layers{l}.type
        case 'fc'
            if l>1
                net.layers{l}.W = randn(net.layers{l}.size,net.layers{l-1}.size);
                net.layers{l}.W = max(net.layers{l}.wmin,net.layers{l}.W);
                net.layers{l}.W = min(net.layers{l}.wmax,net.layers{l}.W);
                if ~isfield(net.layers{l},'Wmask')
                    net.layers{l}.Wmask = ones(size(net.layers{l}.W));
                end
                net.layers{l}.b = randn(1,net.layers{l}.size);
                net.layers{l}.b = max(net.layers{l}.wmin,net.layers{l}.b);
                net.layers{l}.b = min(net.layers{l}.wmax,net.layers{l}.b);
                if ~isfield(net.layers{l},'bmask')
                    net.layers{l}.bmask = ones(size(net.layers{l}.b));
                end
                net.layers{l}.f  = @(s) 1./(1+exp(-s));
                net.layers{l}.fp = @(s) net.layers{l}.f(s).*(1-net.layers{l}.f(s));
            else
                net.layers{l}.f  = @(s) s;
                net.layers{l}.fp = @(s) 1;
            end
            net.layers{l}.x = zeros(1,net.layers{l}.size);
            net.layers{l}.s = zeros(1,net.layers{l}.size);        
        case 'spike'
            if l>1
                net.layers{l}.W = randn(net.layers{l}.size,net.layers{l-1}.size);
                if ~isfield(net.layers{l},'Wmask')
                    net.layers{l}.Wmask = ones(size(net.layers{l}.W));
                end
                net.layers{l}.b = randn(1,net.layers{l}.size);
                if ~isfield(net.layers{l},'bmask')
                    net.layers{l}.bmask = ones(size(net.layers{l}.b));
                end
                net.layers{l}.fp = @(s) (1./(1+exp(-s))).*(1-1./(1+exp(-s)));
            end
            net.layers{l}.x = zeros(1,net.layers{l}.size);
            net.layers{l}.s = zeros(1,net.layers{l}.size);
            net.layers{l}.state = zeros(1,net.layers{l}.size);
            if l==1
                net.layers{l}.theta = 1.0;
            else
                net.layers{l}.theta = 1.0;
            end
        case 'spikeevent'
            if l>1
                net.layers{l}.W = randn(net.layers{l}.size,net.layers{l-1}.size);
                net.layers{l}.b = randn(1,net.layers{l}.size);
            end
            net.layers{l}.x = zeros(1,net.layers{l}.size);
            net.layers{l}.tsorted = {};
            net.layers{l}.t = cell(1,net.layers{l}.size);
            net.layers{l}.t(1,:) = {-100};
            net.layers{l}.tlast = -100*ones(1,net.layers{l}.size);
            net.layers{l}.s = zeros(1,net.layers{l}.size);
            net.layers{l}.theta = 1;
            net.layers{l}.trefrac = 1;
        case 'conv'
            if l>1
                filterlocations = (sqrt(net.layers{l-1}.size)-net.layers{l}.filtersize+1)^2;
                net.layers{l}.size = filterlocations*net.layers{l}.numfilters;
                net.layers{l}.W = zeros(net.layers{l}.numfilters*filterlocations,net.layers{l-1}.size);
                net.layers{l}.Wmask = zeros(net.layers{l}.numfilters*filterlocations,net.layers{l-1}.size);
                net.layers{l}.Wshare = cell(1,net.layers{l}.numfilters);
                net.layers{l}.b = randn(1,net.layers{l}.size);
                net.layers{l}.bmask = ones(size(net.layers{l}.b));
                k = 1;
                for filternumber=1:net.layers{l}.numfilters
                    %filter = randn(net.layers{l}.filtersize);
                    filter = repmat([-1 1 -1 1],4,1);
                    for i=1:sqrt(net.layers{l-1}.size)-net.layers{l}.filtersize+1
                        for j=1:sqrt(net.layers{l-1}.size)-net.layers{l}.filtersize+1
                            tmp = zeros(sqrt(net.layers{l-1}.size));
                            tmp(i:i+net.layers{l}.filtersize-1,j:j+net.layers{l}.filtersize-1) = filter;
                            net.layers{l}.W(k,:) = reshape(tmp,1,[]); 
                            tmp = zeros(sqrt(net.layers{l-1}.size));
                            tmp(i:i+net.layers{l}.filtersize-1,j:j+net.layers{l}.filtersize-1) = ones(net.layers{l}.filtersize);
                            net.layers{l}.Wmask(k,:) = reshape(tmp,1,[]);
                            k = k+1;
                        end
                    end
                    net.layers{l}.Wshare{filternumber} = (filternumber-1)*filterlocations+1:filternumber*filterlocations;
                end
            end
            net.layers{l}.x = zeros(1,net.layers{l}.size);
            net.layers{l}.s = zeros(1,net.layers{l}.size);
            net.layers{l}.f  = @(s) 1./(1+exp(-s));
            net.layers{l}.fp = @(s) net.layers{l}.f(s).*(1-net.layers{l}.f(s));
            
        otherwise
            error(['Invalid Layer Type: ' net.layers{l}.type]);
   end
end

% % FF Network
% if strcmp(type,'ff')
% 
%     net.W = cell(1,length(net.layers));
%     net.Wmask = cell(1,length(net.layers));
%     net.x = cell(1,length(net.layers));
%     net.s = cell(1,length(net.layers));
%     net.f = cell(1,length(net.layers));
%     net.fp = cell(1,length(net.layers));
%     for l=1:length(net.layers)
%         if l>1
%             net.W{l} = (net.wmin(l)+net.wmax(l))/2+1*randn(net.layers{l}.size,net.layers{l-1}.size+1); % +1 for bias
%             net.Wmask{l} = ones(net.layers{l}.size,net.layers{l-1}.size+1);
%         end
%         net.s{l} = zeros(net.layers{l}.size,1);
%         net.x{l} = zeros(net.layers{l}.size,1);
%         net.f{l}  = @(s) 1./(1+exp(-net.a(l)*s));
%         net.fp{l} = @(s) net.a(l)*net.f{l}(s).*(1-net.f{l}(s));
%     end
%     
% % Convolution net
% elseif strcmp(type,'cnn')
% 
%     net.W = cell(1,length(net.layers));
%     net.Wmask = cell(1,length(net.layers));
%     net.x = cell(1,length(net.layers));
%     net.s = cell(1,length(net.layers));
%     net.f = cell(1,length(net.layers));
%     net.fp = cell(1,length(net.layers));
%     net.Wshare = cell(1,length(net.layers));
%     for l=1:length(net.layers)
%         if l>1
%             net.W{l} = (net.wmin(l)+net.wmax(l))/2+1*randn(net.layers{l}.size,net.layers{l-1}.size+1); % +1 for bias
%             net.Wmask{l} = ones(net.layers{l}.size,net.layers{l-1}.size+1);
%             
%             filterlocations = (sqrt(net.layers{l-1}.size)-net.layers{l}.filtersize+1)^2;
%             net.W{l} = zeros(net.layers{l}.numfilters*filterlocations,net.layers{l-1}.size);
%             net.Wmask{l} = zeros(net.layers{l}.numfilters*filterlocations,net.layers{l-1}.size);
%             net.Wshare{l} = cell(1,net.layers{l}.numfilters);
%             k = 1;
%             for filternumber=1:net.layers{l}.numfilters
% 	            filter = randn(net.layers{l}.filtersize);
%                 for i=1:sqrt(net.layers{l-1}.size)-net.layers{l}.filtersize+1
%                     for j=1:sqrt(net.layers{l-1}.size)-net.layers{l}.filtersize+1
%                         tmp = zeros(sqrt(net.layers{l-1}.size));
%                         tmp(i:i+net.layers{l}.filtersize-1,j:j+net.layers(l).filtersize-1) = filter;
%                         net.W{l}(k,:) = reshape(tmp,1,[]); 
%                         tmp = zeros(sqrt(net.layers{l-1}.size));
%                         tmp(i:i+net.layers{l}.filtersize-1,j:j+net.layers(l).filtersize-1) = ones(net.layers(l).filtersize);
%                         net.Wmask{l}(k,:) = reshape(tmp,1,[]);
%                         k = k+1;
%                     end
%                 end
%                 net.Wshare{l}{filternumber} = (filternumber-1)*filterlocations+1:filternumber*filterlocations;
%             end
%         end
%         net.s{l} = zeros(1,net.layers{l}.size);
%         net.x{l} = zeros(1,net.layers{l}.size);
%         net.f{l}  = @(s) 1./(1+exp(-net.a(l)*s));
%         net.fp{l} = @(s) net.a(l)*net.f{l}(s).*(1-net.f{l}(s));
%     end
%     
% % ESN
% elseif strcmp(type,'esn'),
%     
%     net.layers = layers;
%     net.W = cell(1,3);
%     net.x = cell(1,3);
%     net.b = cell(1,3);
%     
%     % Input to reservoir
%     net.W{1} = 0.1*unifrnd(-1,1,net.layers(2).size,net.layers(1).size);
%     net.x{1} = zeros(net.layers(1).size,1);
%     
%     % Reservoir
%     net.W{2} = sprand(net.layers(2).size,net.layers(2).size,0.2);
%     net.W{2} = 2*net.W{2}-(net.W{2}~=0);
%     net.W{2} = 0.9*net.W{2}/max(abs(eigs(net.W{2})));
%     net.b{2} = 0.1*unifrnd(-1,1,net.layers(2).size,1);
%     net.x{2} = zeros(net.layers(2).size,1);   
%     net.f = @(s) tanh(s);
%     net.leak = 0.9;
%     
%     % Outputs
%     net.W{3} = unifrnd(-1,1,net.layers(3).size,net.layers(2).size); 
%     net.b{3} = unifrnd(-1,1,net.layers(3).size,1);
%     net.x{3} = zeros(net.layers(3).size,1);
% 
% % LSM
% elseif strcmp(type,'lsm'),
%     
%     net.layers = layers;
%     net.W = cell(1,3);
%     net.x = cell(1,3);
%     net.s = cell(1,3);
%     net.state = cell(1,3);
%     
%     % Input to reservoir
%     net.W{1} = unifrnd(-1,1,net.layers(2).size,net.layers(1).size+1); % +1 for bias
%     net.W{1}(rand(net.layers(2).size,net.layers(1).size+1)<0.0) = 0;
%     net.s{1} = zeros(net.layers(1).size,1);
%     net.x{1} = zeros(net.layers(1).size+1,1);
%     net.state{1} = zeros(net.layers(1).size,1);
%     net.rate{1} = zeros(net.layers(1).size+1,1);
%     
%     % Reservoir
%     net.W{2} = unifrnd(-1,1,net.layers(2).size,net.layers(2).size);
%     net.W{2}(rand(net.layers(2).size,net.layers(2).size)<0.0) = 0;
%     net.W{2} = 0.9*net.W{2}/max(abs(eig(net.W{2}))); % Scale spectral radius
%     net.s{2} = zeros(net.layers(2).size,1);
%     net.x{2} = zeros(net.layers(2).size+1,1);        % +1 for bias
%     net.state{2} = zeros(net.layers(2).size,1);
%     net.rate{2} = zeros(net.layers(2).size+1,1);
%     net.W{2}(eye(size(net.W{2}))==1) = 0;            % Don't allow self connections
%     
%     % Outputs
%     net.W{3} = unifrnd(-1,1,net.layers(3).size,net.layers(2).size+1); % +1 for bias 
%     net.s{3} = zeros(net.layers(3).size,1);
%     net.x{3} = zeros(net.layers(3).size,1);
%     net.state{3} = zeros(net.layers(3).size,1);
%     net.rate{3} = zeros(net.layers(3).size,1);   
%     
% % BPTT network
% elseif strcmp(type,'bptt'),
%     
%     net.x = cell(1,3);
%     net.s = cell(1,3);
%     net.f = cell(1,3);
%     net.fp = cell(1,3);
%     net.W{1} = randn(net.layers(2).size,net.layers(1).size+1);
%     net.W{2} = randn(net.layers(2).size,net.layers(2).size);
%     net.W{3} = randn(net.layers(3).size,net.layers(2).size+1);
%     net.s{1} = zeros(1,net.layers(1).size);
%     net.s{2} = zeros(1,net.layers(2).size);
%     net.s{3} = zeros(1,net.layers(3).size);
%     net.x{1} = zeros(1,net.layers(1).size+1);
%     net.x{2} = zeros(1,net.layers(2).size+1);
%     net.x{3} = zeros(1,net.layers(3).size);
%     net.f{2}  = @(s) 1./(1+exp(-s));
%     net.fp{2} = @(s) net.f{2}(s).*(1-net.f{2}(s));
%     net.f{3}  = @(s) 1./(1+exp(-s));
%     net.fp{3} = @(s) net.f{2}(s).*(1-net.f{2}(s));
% %    net.f{3} = @(s) s;
% %    net.fp{4} = @(s) 1;
% %     net.f{2} = @(s) tanh(s);
% %     net.fp{2} = @(s) sech(s).^2;
% %     net.f{3} = @(s) tanh(s);
% %     net.fp{3} = @(s) sech(s).^2;
% 
% elseif strcmp(type,'lstm'),
%     
%     net.yhat = zeros(net.layers(3).size,1);                     % Outputs
%     net.x    = zeros(net.layers(2).size,1);                     % Hidden state
%     net.h    = zeros(net.layers(2).size,1);                     % Ungated hidden state
%     net.o    = zeros(net.layers(2).size,1);                     % Output gate
%     net.c    = zeros(net.layers(2).size,1);                     % Memory cell
%     net.ctilde = zeros(net.layers(2).size,1);                   % New memory
%     net.g    = zeros(net.layers(2).size,1);                     % Input 1 to input gate
%     net.i    = zeros(net.layers(2).size,1);                     % Input 2 to input gate   
%     net.Wyx  = randn(net.layers(2).size,net.layers(1).size);    % To output from hidden state
%     net.Wou  = randn(net.layers(2).size,net.layers(1).size);    % To o from input
%     net.Wox  = randn(net.layers(2).size,net.layers(2).size);    % To o from hidden state
%     net.Wiu  = zeros(net.layers(2).size,net.layers(1).size);    % To i from input
%     net.Wix  = zeros(net.layers(2).size,net.layers(2).size);    % To i from hidden state
%     net.Wgu  = zeros(net.layers(2).size,net.layers(1).size);    % To g from input
%     net.Wgx  = zeros(net.layers(2).size,net.layers(2).size);    % To g from hidden state    
%     net.byhat= randn(net.layers(3).size,1);                     % Bias to output
%     net.bo   = randn(net.layers(2).size,1);                     % Bias to o
%     net.bg   = randn(net.layers(2).size,1);                     % Bias to g
%     net.bi   = randn(net.layers(2).size,1);                     % Bias to i
%     
% else
%     error(['Invalid network type: ' net.type]);
% end
% 



