function [net,J] = nngetcost(net,U,Y)
%NNGETCOST returns the cost (objective) function for the passed net
%   NETGETCOST = NNGETCOST(NET,U,Y) returns the cost metrics for the passed
%   NET, given the inputs U, the expected outputs Y

%   Author: Cory Merkel
%   Air Force Research Laboratory

% Calculate the cost
m = size(U,1);
sse = 0;
accuracy = 0;
cm = zeros(size(Y,2));
Yhat = zeros(size(Y));
for p=1:m
    if iscell(U)
        net = nnsim(net,U{p});
    else
        net = nnsim(net,U(p,:));
    end
    yhat = net.layers{end}.x;
    Yhat(p,:) = yhat;
    sse = sse + sum((Y(p,:)-yhat).^2); % MSE
    if size(Y,2)>1
        if(numel(find(yhat==max(yhat)))==1 && numel(find(Y(p,:)==max(Y(p,:))))==1) % Accuracy (WTA)
            accuracy = accuracy + ... 
         100*(find(yhat==max(yhat))==(find(Y(p,:)==max(Y(p,:)))))/size(U,1);
        end
    else
        accuracy = accuracy + 100*all(round(net.layers{end}.x)==Y(p,:))/size(U,1); % Accuracy (Rounding)
    end
    cm(find(Y(p,:)),find(yhat==max(yhat))) = cm(find(Y(p,:)),find(yhat==max(yhat),1)) + 1; %#ok<FNDSB>
end
J.mse = sse/m;
J.accuracy = accuracy;
J.cm = cm;
R = corrcoef([Yhat Y]);
J.r = R;
J.Yhat = Yhat;

