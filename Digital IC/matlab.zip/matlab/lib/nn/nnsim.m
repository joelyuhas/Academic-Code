function [net] = nnsim(net,u)
%NNSIM simulates a neural network
%   NET = NNSIM(NET,U) simulates the passed neural network NET with the 
%   inputs U.  

%   Author: Cory Merkel
%   Air Force Research Laboratory
  

for l=1:length(net.layers)
    switch net.layers{l}.type
        case 'fc'
            if l==1
                net.layers{l}.s = u;
                net.layers{l}.x = net.layers{1}.s;
            else
                net.layers{l}.s = net.layers{l-1}.x*net.layers{l}.W'+net.layers{l}.b;
                net.layers{l}.x = net.layers{l}.f(net.layers{l}.s);
            end
        case 'spike'
            if l==1
                net.layers{l}.s = net.layers{l}.s + u;
            else
                net.layers{l}.s = net.layers{l}.s + net.layers{l-1}.x*net.layers{l}.W'+net.layers{l}.b;
            end     
            net.layers{l}.state(net.layers{l}.state==2) = 0;
            net.layers{l}.state(net.layers{l}.state==1) = 2;
            net.layers{l}.state((net.layers{l}.state==0)&(net.layers{l}.s>=net.layers{l}.theta)) = 1;
            net.layers{l}.x = zeros(1,net.layers{l}.size);
            net.layers{l}.x(net.layers{l}.state==1) = 1;
            net.layers{l}.s(net.layers{l}.state==2) = 0;
        case 'spikeevent'
%             if l==1
%                 net.layers{l}.tsorted = u;
%             else
%                 window = 1;
%                 tlast = 0;
%                 net.layers{l}.tsorted = {};
%                 i = 1;
%                 while i<=length(net.layers{l-1}.tsorted)
%                     tcurrent = net.layers{l-1}.tsorted{i}{1};
%                     net.layers{l}.tlast;
%                     eligible = tcurrent > (net.layers{l}.tlast+net.layers{l}.trefrac);
%                     indexfrom = net.layers{l-1}.tsorted{i}{2};
%                     net.layers{l}.s = max(0,net.layers{l}.s+eligible.*(sum(net.layers{l}.W(:,indexfrom),2)'+net.layers{l}.b));
%                     indexto = find((net.layers{l}.s>net.layers{l}.theta)&(tcurrent > net.layers{l}.tlast+net.layers{l}.trefrac));
%                     net.layers{l}.s(indexto) = 0;
%                     net.layers{l}.tsorted{end+1} = {tcurrent,indexto};
%                     net.layers{l}.tlast(indexto) = tcurrent;
% %                     i = i+1;
% 
%             net.layers{l}.t = cell(1,net.layers{l}.size);
%             for i=1:length(net.layers{l}.tsorted)
%                 t = net.layers{l}.tsorted{i}{1};
%                 for j = 1:length(net.layers{l}.tsorted{i}{2})
%                     neuron = net.layers{l}.tsorted{i}{2}(j);
%                     net.layers{l}.t{neuron}(end+1) = t;
%                 end
%             end
%             net.layers{l}.tlast = -100;
            
            
%             % Rate coding with window
%             if l==1
%                 net.layers{l}.tsorted = u;
%             else
%                 %net.layers{l}.s = zeros(1,net.layers{l}.size);  % This needs to be moved if multiple windows are going to be simulated
%                 tlast = 0;
%                 window = 1;
%                 net.layers{l}.tsorted = {};
%                 i = 1; 
%                 tcurrent = 0;
%                 while i<=length(net.layers{l-1}.tsorted)
%                     tcurrent = net.layers{l-1}.tsorted{i}{1};
%                     if tcurrent >= window*net.windowsize
%                         net.layers{l}.s = max(0,net.layers{l}.s+net.layers{l}.b*(window*net.windowsize-tlast));  % Add remaining bias
%                         for j=1:net.windowsize  % Vectorize this loop if possible
%                             indexto = find((net.layers{l}.s-(j-1)*1)>net.layers{l}.theta);
%                             if any(indexto)
%                                 net.layers{l}.tsorted{end+1} = {window*net.windowsize+(j-1)+1,indexto};
%                             else
%                                 break;
%                             end
%                         end
%                         net.layers{l}.s = zeros(1,net.layers{l}.size);
%                         tlast = window*net.windowsize;
%                         window = window+1;
%                     else
%                         indexfrom = net.layers{l-1}.tsorted{i}{2};
%                         net.layers{l}.s = max(0,net.layers{l}.s+sum(net.layers{l}.W(:,indexfrom),2)'+net.layers{l}.b*(tcurrent-tlast));
%                         tlast = tcurrent;
%                     end
%                     i = i+1;
%                 end
%                 
%                 % Get the last window...
%                 net.layers{l}.s = max(0,net.layers{l}.s+net.layers{l}.b*((window+1)*net.windowsize-tlast)); % Add remaining bias
%                 for j=1:net.windowsize  % Vectorize this loop if possible
%                     indexto = find((net.layers{l}.s-(j-1)*1)>net.layers{l}.theta);
%                     if any(indexto)
%                         net.layers{l}.tsorted{end+1} = {window*net.windowsize+(j-1)+1,indexto};
%                     else
%                         break;
%                     end
%                 end
%             end
%             
%             net.layers{l}.t = cell(1,net.layers{l}.size);
%             for i=1:length(net.layers{l}.tsorted)
%                 t = net.layers{l}.tsorted{i}{1};
%                 for j = 1:length(net.layers{l}.tsorted{i}{2})
%                     neuron = net.layers{l}.tsorted{i}{2}(j);
%                     net.layers{l}.t{neuron}(end+1) = t;
%                 end
%             end
%      

            % Rate coding over one window
            if l==1
                net.layers{l}.tsorted = u;
            else
                net.layers{l}.s = zeros(1,net.layers{l}.size);
                tlast = 0;
                net.layers{l}.tsorted = {};
                tcurrent = 0;
                for i=1:length(net.layers{l-1}.tsorted)
                    tcurrent = net.layers{l-1}.tsorted{i}{1}; 
                    indexfrom = net.layers{l-1}.tsorted{i}{2};
                    net.layers{l}.s = max(0,net.layers{l}.s+sum(net.layers{l}.W(:,indexfrom),2)'+net.layers{l}.b*(tcurrent-tlast));
                    tlast = tcurrent;
                end
                net.layers{l}.s = max(0,net.layers{l}.s+net.layers{l}.b*(net.windowsize-tlast));  % Add remaining bias
                for j=1:net.windowsize  % Vectorize this loop if possible
                    indexto = find((net.layers{l}.s-(j-1)*1)>net.layers{l}.theta);
                    if any(indexto)
                        net.layers{l}.tsorted{end+1} = {j,indexto};
                    else
                        break;
                    end
                end
            end
            
            net.layers{l}.t = cell(1,net.layers{l}.size);
            for i=1:length(net.layers{l}.tsorted)
                t = net.layers{l}.tsorted{i}{1};
                for j = 1:length(net.layers{l}.tsorted{i}{2})
                    neuron = net.layers{l}.tsorted{i}{2}(j);
                    net.layers{l}.t{neuron}(end+1) = t;
                end
            end
            net.layers{l}.x = cellfun(@(x) length(x)/net.windowsize,net.layers{l}.t);
     
            
        case 'conv'
            if l==1
                 net.layers{l}.s = u;
                 net.layers{l}.x = net.layers{1}.s;
            else
                net.layers{l}.s = net.layers{l-1}.x*net.layers{l}.W'+net.layers{l}.b;
                net.layers{l}.x = net.layers{l}.f(net.layers{l}.s);
            end
        otherwise
            error(['Invalid layer type: ' net.layers{l}.type])
    end
end


% if strcmp(net.type,'ff')||strcmp(net.type,'cnn')
% 
%     % Simulate the input neurons with identity activation function
%     net.layers(1).s = u;
%     net.layers(1).x = net.layers(1).s;
% 
%     % Calculate the output of each layer
%     for l=2:length(net.layers)
%         switch net.layers{l}.activationtype
%             case 'sum'
%                 net.s{l} = net.layers{l-1}.x*net.layers{l}.W';
%             case 'product'
%                 net.s{l} = prod(net.W{l}.*(net.x{l-1}(:,ones(1,net.layers{l}.size)))',2);
%             otherwise
%                 error(['Invalid activation type: ' net.layers{l}.type])
%         end
%         net.layers{l}.x = net.layers{l}.f(net.layers{l}.s);
%     end
%  
% % BPTT
% elseif strcmp(net.type,'bptt'),
%     net.s{1} = u;
%     net.x{1} = [1 net.s{1}];
%     net.s{2} = (net.W{1}*net.x{1}'+net.W{2}*net.x{2}(2:end)')';
%     net.x{2} = [1 net.f{2}(net.s{2})];
%     net.s{3} = (net.W{3}*net.x{2}')';
%     net.x{3} = net.f{3}(net.s{3});
%     
% % LSTM
% elseif strcmp(net.type,'lstm'),
%     
%     fsig = @(s) 1./(1+exp(-s));    
%     net.g = fsig(net.Wgu*u+net.Wgx*net.x+net.bg);
%     net.i = fsig(net.Wiu*u+net.Wix*net.x+net.bi);
%     net.o = fsig(net.Wou*u+net.Wox*net.x+net.bo);
%     net.ctilde = net.g.*net.i;
%     net.c = net.c+net.ctilde;
%     net.h = fsig(net.c);
%     net.x = net.h.*net.o;
%     net.yhat = fsig(net.x+net.byhat);
% 
% % ESN    
% elseif strcmp(net.type,'esn'),
% 
%     net.x{1} = u;
%     xnew = net.f(net.W{1}*net.x{1}+net.W{2}*net.x{2}+net.b{2});
%     net.x{2} = net.leak*xnew+(1-net.leak)*net.x{2};
%     net.x{3} = net.W{3}*net.x{2}+net.b{3};
% 
% % LSM
% elseif strcmp(net.type,'lsm'),
% 
%     % Simulate the input neurons with identity activation function
%     % and add 1 for bias input
%     sth = 0.6;
%     st = 1;
%     rt = 1;
%     leak = 0.15;
%     
%     net.state{1} = mod(net.state{1} + (net.state{1}~=0),st+rt+1);
%     net.s{1} = max(net.s{1} + u'-leak,0);
%     net.state{1} = net.state{1} + (net.state{1}==0).*(net.s{1}>=sth);
%     net.s{1} = net.s{1}.*(net.state{1}==0);
%     net.x{1} = [1; (net.state{1}>0).*(net.state{1}<2)];
%     net.rate{1} = min(10,max(0,net.rate{1}+net.x{1}-0.2*net.rate{1}));
% 
%     % Reservoir layer
%     net.state{2} = mod(net.state{2} + (net.state{2}~=0),st+rt+1);
%     net.s{2} = max(0.1*net.s{2}+0.9*(net.W{1}*net.x{1}+net.W{2}*net.x{2}(2:end))-leak,0);
%     net.state{2} = net.state{2} + (net.state{2}==0).*(net.s{2}>=sth);
%     net.s{2} = net.s{2}.*(net.state{2}==0);
%     net.x{2} = [1; (net.state{2}>0).*(net.state{2}<2)];
%     net.rate{2} = min(10,max(0,net.rate{2}+net.x{2}-0.2*net.rate{2}));
%     
%     % Output layer
%     net.state{3} = mod(net.state{3} + (net.state{3}~=0),st+rt+1);
%     net.s{3} = max(net.s{3}+net.W{3}*net.x{2}-leak,0); 
%     net.state{3} = net.state{3} + (net.state{3}==0).*(net.s{3}>=sth);
%     net.s{3} = net.s{3}.*(net.state{3}==0);
%     net.x{3} = (net.state{3}>0).*(net.state{3}<2);
%     net.rate{3} = min(10,max(0,net.rate{3}+net.x{3}-0.2*net.rate{3}));
%     
% else
%    error(['Invalid network type: ' net.type]) 
% end

