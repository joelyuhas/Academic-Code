

def scale():
    fileName = input("Enter file name: ")
    #outFilename = input("Enter output file name: ")
    outFile = open("test_input.txt", "w")
    file = open(fileName, 'r')

    matrix = []
    isFirst = True
    lineLen = -1
    for line in file:
        line = line.strip().split("\t")
        if isFirst:
            lineLen = len(line)
            matrix.append(line)
        elif lineLen == len(line):
            matrix.append(line)
        else:
            print('Line Length Not Match.\n')

    inputSize = 3

    if len(matrix) == lineLen:
        for i in range(lineLen-2):
            lines = ''
            isFirst = True
            for j in range(lineLen-2):
                if isFirst:
                    inputs = matrix[i][j] + matrix[i][j+1] + matrix[i][j+2] + \
                             matrix[i+1][j] + matrix[i+1][j+1] + matrix[i+1][j+2] + \
                             matrix[i+2][j] + matrix[i+2][j+1] + matrix[i+2][j+2]
                    lines += inputs
                    isFirst = False
                else:
                    inputs = matrix[i][j] + matrix[i][j+1] + matrix[i][j+2] + \
                             matrix[i+1][j] + matrix[i+1][j+1] + matrix[i+1][j+2] + \
                             matrix[i+2][j] + matrix[i+2][j+1] + matrix[i+2][j+2]
                    lines += ' ' + inputs
            outFile.write(lines + '\n')
    else:
        print('Matrix length n != m')


    outFile.close()
    file.close()


scale()




