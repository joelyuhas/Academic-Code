

def scale():
    fileName = input("Enter file name: ")
    #outFilename = input("Enter output file name: ")
    outFile = open("weight.txt", "w")
    file = open(fileName, 'r')

    lines = ''
    for line in file:
        line = line.strip()
        if len(line) > 1:
            lines += line

    outFile.write(lines)
    

    outFile.close()
    file.close()


scale()




