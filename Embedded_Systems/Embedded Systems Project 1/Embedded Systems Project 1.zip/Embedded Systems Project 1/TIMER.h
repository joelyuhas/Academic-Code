// Z. Weeden Feb. 12, 2017
// function prototypes for Timer
void init_timer(void);
void start_timer(void);
unsigned int timer_now(void);
void stop_timer(void);
int is_event(void);